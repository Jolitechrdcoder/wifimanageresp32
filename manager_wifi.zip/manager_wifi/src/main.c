#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_mac.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include <lwip/api.h>
#include <esp_http_server.h>
#include "esp_mac.h"
#include "lwip/err.h"
#include "lwip/sys.h"
#include"AP_Jorge/ap_jorge.h"
#include"webServer_jorge/webser.h"
#include"driver/gpio.h"
#include"mqtt_jorge/mqtt1.h"
#include"wifi_jorge/wifi1.h"
#include"eproom_jorge/eproom.h"

#define cambio 18
char SSID[32] ="SSID";
char PASSWORD[32] ="PASSWORD";

esp_mqtt_client_handle_t Client;
// extern typedefFLAGS Flag;

// main principal
void app_main(void)
{

    // gpio config

    gpio_set_direction(cambio,GPIO_MODE_INPUT);
    // resistencia  pull up 
    gpio_set_pull_mode(cambio,GPIO_PULLUP_ONLY);

    int statutsbtn = gpio_get_level(cambio); 

    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);
    
    if(!statutsbtn){
         iniciar_ap();
         configurar_servidor();
    }
    else{
        read_data_from_eeprom("SSID",SSID);
        read_data_from_eeprom("PASSWORD",PASSWORD);
        wifi_init_sta(SSID,PASSWORD);
        
        }



    while (1)
    {  
        vTaskDelay(500 / portTICK_PERIOD_MS);
    }
}
