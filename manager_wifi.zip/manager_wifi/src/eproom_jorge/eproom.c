
#include<eproom_jorge/eproom.h>
static const char *TAG1 = "EEPROM Example";

void write_data_to_eeprom(char *ID,char *data_to_write) {
    nvs_handle_t nvs_handle;
    esp_err_t err;

    // Abre el espacio de almacenamiento en la EEPROM
    err = nvs_open("storage", NVS_READWRITE, &nvs_handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG1, "Error opening NVS handle: %s", esp_err_to_name(err));
        return;
    }

    // Escribe datos en la EEPROM
    err = nvs_set_str(nvs_handle, ID, data_to_write);
    if (err != ESP_OK) {
        ESP_LOGE(TAG1, "Error writing to NVS: %s", esp_err_to_name(err));
    }
    // Cierra el espacio de almacenamiento
    nvs_commit(nvs_handle);
    nvs_close(nvs_handle);
}

void read_data_from_eeprom(char *ID,char *DATA) {
    nvs_handle_t nvs_handle;
    esp_err_t err;

    // Abre el espacio de almacenamiento en la EEPROM
    err = nvs_open("storage", NVS_READWRITE, &nvs_handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG1, "Error opening NVS handle: %s", esp_err_to_name(err));
        return;
    }

    // Lee datos de la EEPROM
    size_t required_size;
  nvs_get_str(nvs_handle, ID, NULL, &required_size);
  err=nvs_get_str(nvs_handle, ID, DATA, &required_size);
 
    if (err != ESP_OK) {
        ESP_LOGE(TAG1, "Error reading from NVS: %s", esp_err_to_name(err));
    } else {
        ESP_LOGI(TAG1, "Data read from EEPROM: %s",DATA);
    }
    // Cierra el espacio de almacenamiento
    nvs_close(nvs_handle);
}
