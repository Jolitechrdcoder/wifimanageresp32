#include"webServer_jorge/webser.h"
#include"webServer_jorge/web.h"
#include"eproom_jorge/eproom.h"
char ssid_value[64] = "";
char password_value[64] = "";
static const char *TAG = "wifi softAP";
esp_err_t send_web_page(httpd_req_t *req)
{
    httpd_resp_send(req, formulario, strlen(formulario));
    return ESP_OK;
}

esp_err_t submit_handler(httpd_req_t *req)
{
    if (req->method == HTTP_POST)
    {
       char content[256];
       int content_len = httpd_req_recv(req, content, sizeof(content));
       content[content_len] = '\0';

       char *posicion_igual_ssid = strchr(content, '=');

    // Verificar si se encontró '='
    if (posicion_igual_ssid != NULL) 
    {
        // Incrementar la posición para obtener el valor después de '='
        char *valor_ssid = posicion_igual_ssid + 1;

        // Buscar la posición del siguiente '&'
        char *posicion_ampersand = strchr(valor_ssid, '&');

        // Verificar si se encontró '&'
        if (posicion_ampersand != NULL)
         {
            // Calcular la longitud del valor de ssid
            size_t longitud_ssid = posicion_ampersand - valor_ssid;

            // Crear y copiar la cadena del valor de ssid
            char ssid[longitud_ssid + 1];
            strncpy(ssid, valor_ssid, longitud_ssid);
            ssid[longitud_ssid] = '\0';

            printf("SSID: %s\n", ssid);
            write_data_to_eeprom("SSID",ssid);
            // Mismo proceso para la contraseña
            char *posicion_igual_password = strchr(posicion_ampersand, '=');

            // Verificar si se encontró '='
            if (posicion_igual_password != NULL) {
                // Incrementar la posición para obtener el valor después de '='
                char *valor_password = posicion_igual_password + 1;

                printf("Password: %s\n", valor_password);
                write_data_to_eeprom("PASSWORD",valor_password);
            }
        }
       printf("%s",content);
    }
    }
    //ESP_LOGI(TAG, "SSID enviado: %s, Contraseña: %s", ssid_value, password_value);

    httpd_resp_set_status(req, "303 See Other");
    httpd_resp_set_hdr(req, "Location", "/");
    httpd_resp_send(req, NULL, 0);

    return ESP_OK;
}

httpd_uri_t uri_get = {
    .uri = "/",
    .method = HTTP_GET,
    .handler = send_web_page,
    .user_ctx = NULL
};

httpd_uri_t uri_submit = {
    .uri = "/submit",
    .method = HTTP_POST,
    .handler = submit_handler,
    .user_ctx = NULL
};

httpd_handle_t configurar_servidor(void)
{
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    httpd_handle_t server = NULL;

    if (httpd_start(&server, &config) == ESP_OK)
    {
        httpd_register_uri_handler(server, &uri_get);
        httpd_register_uri_handler(server, &uri_submit);
    }

    return server;
}