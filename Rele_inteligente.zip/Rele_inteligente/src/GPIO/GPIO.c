#include<GPIO/GPIO.h>


gpio_config_t Mode_config = {

		.pin_bit_mask = (1ULL <<Mode),
		.mode = GPIO_MODE_INPUT,
		.intr_type = GPIO_INTR_DISABLE,
		.pull_up_en = 0,
		.pull_down_en = 0,
		}
;
void GPIO_INIT(void)
{
gpio_config(&Mode_config);

}
