#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_mac.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include <lwip/api.h>
#include <esp_http_server.h>
#include "esp_mac.h"
#include "lwip/err.h"
#include "lwip/sys.h"
#include "nvs.h"
#include "driver/gpio.h"
#include"WIFI_SOFTAP/WIFI_SOFTAP.h"
#include"WEB_SERVER/WEB_SERVER.h"
#include"GPIO/GPIO.h"
#include"WIFI/wifi1.h"
#include"MQTT/MQTT.h"
#include"EPROOM/EPROOM.h"
char SSID[32]="\0";
char PASSWORD[32]="\0";
void app_main(void)
{
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);
    
    
    GPIO_INIT();

    if(gpio_get_level(Mode))
    {
    wifi_init_softap();
    setup_server();
    }
    else
    {
        read_data_from_eeprom("SSID",SSID);
        read_data_from_eeprom("PASSWORD",PASSWORD);
        wifi_init_sta(SSID,PASSWORD);
    }


    while (1)
    {
        vTaskDelay(5000 / portTICK_PERIOD_MS);
    }
}